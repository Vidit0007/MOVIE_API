import React from "react"
import Header from './ASSETS/Header';


function Contact() {
    return (
      <>
     
      <Header />
       <section className='Contact'>
       
     </section>
     </>
    )
  }
  
  export default Contact