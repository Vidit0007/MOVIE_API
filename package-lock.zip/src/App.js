import {BrowserRouter, Route,Routes} from 'react-router-dom'
import Login from './Login';
import React, {useState} from 'react';
import Home from './Home';
import About from './About'
import Error from './Error'
import Contact from './Contact';
import Register from './Register';
import Dashboard from './Dashboard';
import './App.css'
function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };
  return (
    <>
     <div>
      {loggedIn ? (
        <div>
          <Home />
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <div>
          <Register onRegister={handleLogin} />
          
        </div>
      )}
    </div>
    <BrowserRouter>
    <Routes>
    <Route exact path="/" element={<Login onLogin={handleLogin}/>} />
      <Route path="/home" element={<Home />} >
      <Route path="/home/about" element={<About />} />
      <Route path="/home/contact" element={<Contact />} />
      <Route  path="/home/dashboard" element={<Dashboard />} />
      </Route>
      <Route path="error" element={<Error />} />
    </Routes>
  </BrowserRouter>
  </>
  );
}

export default App;
