import React from 'react';
import Header from './ASSETS/Header';


function Dashboard() {
  return (
    <>
      <Header />
      <section className='dashboard'>
        <h1> JAB LOGIN PROPER BAN JAYE TAB ANA</h1>
      </section>
    </>
  );
}

export default Dashboard;
