import React from "react"
import Header from './ASSETS/Header';


function About() {

    return (
      <>
     
      <Header />
       <section className='home'>
       
     </section>
     </>
    )
  }
  
  export default About